# 目前合成丹药一共36种，共计经验36000点
MIXELIXIRCONFIG = {
    "收取等级": {  # 共3级，多收取3个药材
        "1": {
            "level_up_cost": 1500
        },
        "2": {
            "level_up_cost": 3000
        },
        "3": {
            "level_up_cost": 6000
        }
    },
    "丹药控火": {  # 共2级，多产出2个丹药
        "1": {
            "level_up_cost": 1000
        },
        "2": {
            "level_up_cost": 4000
        }
    }
}
